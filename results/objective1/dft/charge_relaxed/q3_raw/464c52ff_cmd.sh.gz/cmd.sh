
set +e
set -uo pipefail
export LC_ALL=C
source $HOME/miniconda3/etc/profile.d/conda.sh
conda activate qe
export OMP_NUM_THREADS=1
mkdir -p pseudo && cp $HOME/pseudo/*.UPF pseudo/ 2>/dev/null

echo "############ $(date +%H:%M:%S) ELASTIC COST REFERENCE ############"
mkdir -p out_ELAS
timeout 39600 mpirun -np 64 pw.x -in ELAS.in > ELAS.out 2>&1
echo "=== ELAS pw exit=$? conv=$(grep -c 'convergence has been achieved' ELAS.out 2>/dev/null || echo 0) iters=$(grep -c 'iteration #' ELAS.out 2>/dev/null || echo 0) ==="
grep -E '^!\s+total energy' ELAS.out 2>/dev/null | tail -1 || true
rm -rf out_ELAS
echo "########## COMPLETE $(date +%H:%M:%S) ##########"
exit 0
