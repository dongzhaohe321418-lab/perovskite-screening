
set +e
set -uo pipefail
export LC_ALL=C
source $HOME/miniconda3/etc/profile.d/conda.sh
conda activate qe
export OMP_NUM_THREADS=1
mkdir -p pseudo && cp $HOME/pseudo/*.UPF pseudo/ 2>/dev/null

echo "############ $(date +%H:%M:%S) POLARON SEED TEST ############"
mkdir -p out_POL
timeout 82800 mpirun -np 64 pw.x -in POL.in > POL.out 2>&1
echo "=== POL pw exit=$? bfgs_done=$(grep -c 'End of BFGS Geometry Optimization' POL.out 2>/dev/null || echo 0) cycles=$(grep -c 'Self-consistent Calculation' POL.out 2>/dev/null || echo 0) ==="
grep -E 'Energy error|Gradient error|bfgs converged' POL.out 2>/dev/null | tail -4 || true
grep -E '^!\s+total energy' POL.out 2>/dev/null | tail -1 || true
grep -E 'total magnetization|absolute magnetization' POL.out 2>/dev/null | tail -4 || true
rm -rf out_POL
echo "########## COMPLETE $(date +%H:%M:%S) ##########"
exit 0
