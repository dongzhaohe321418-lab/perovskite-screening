
# errexit is imposed by the runner; a grep that finds nothing would abort the script.
# Disable it explicitly and guard every grep with || true.
set +e
set -uo pipefail
export LC_ALL=C
source $HOME/miniconda3/etc/profile.d/conda.sh
conda activate qe
export OMP_NUM_THREADS=1
mkdir -p pseudo && cp $HOME/pseudo/*.UPF pseudo/ 2>/dev/null

OLD=$(ls -dt /home/ericdft/scratch/.claude-science/jobs/*32d8fd27* | head -1)

# --- P1: SCF already converged in the previous job; reuse its wavefunctions ---
cp $OLD/P1.out . 2>/dev/null
if [ -d "$OLD/out_P1" ]; then
  echo "reusing converged P1 wavefunctions: $(du -sh $OLD/out_P1 | cut -f1)"
  mkdir -p out_P1 && cp -r $OLD/out_P1/. out_P1/ 2>/dev/null
  cat > proj_P1.in <<'EOF'
&PROJWFC
   prefix  = 'P1'
   outdir  = './out_P1'
   ngauss  = 0
   degauss = 0.005
   DeltaE  = 0.01
   filpdos = 'P1'
   filproj = 'P1.proj'
/
EOF
  echo "############ $(date +%H:%M:%S) P1 projwfc ############"
  timeout 9000 mpirun -np 64 projwfc.x -in proj_P1.in > proj_P1.out 2>&1
  echo "=== P1 projwfc exit=$? done=$(grep -c 'JOB DONE' proj_P1.out 2>/dev/null || echo 0) ==="
  rm -rf out_P1
else
  echo "P1 wavefunctions gone -- P1 projection cannot be redone without rerunning the SCF"
fi

# --- P2: nspin=2, moment unconstrained, restart from q0A density ---
SRCJD=$(ls -dt /home/ericdft/scratch/.claude-science/jobs/*dac2b686* | head -1)
mkdir -p out_P2
if [ -d "$SRCJD/out/q0A.save" ]; then
  cp -r "$SRCJD/out/q0A.save" out_P2/P2.save 2>/dev/null
  echo "staged q0A density for P2 restart"
else
  echo "q0A.save missing -- P2 starts from atomic superposition"
  sed -i "s/   startingpot = 'file'//" P2.in
fi
echo "############ $(date +%H:%M:%S) START P2 ############"
timeout 32400 mpirun -np 64 pw.x -in P2.in > P2.out 2>&1
echo "=== P2 pw exit=$? conv=$(grep -c 'convergence has been achieved' P2.out 2>/dev/null || echo 0) iters=$(grep -c 'iteration #' P2.out 2>/dev/null || echo 0) ==="
grep -E '^!\s+total energy' P2.out 2>/dev/null | tail -1 || true
grep -E 'total magnetization' P2.out 2>/dev/null | tail -3 || true
if grep -q 'convergence has been achieved' P2.out 2>/dev/null; then
  cat > proj_P2.in <<'EOF'
&PROJWFC
   prefix  = 'P2'
   outdir  = './out_P2'
   ngauss  = 0
   degauss = 0.005
   DeltaE  = 0.01
   filpdos = 'P2'
   filproj = 'P2.proj'
/
EOF
  timeout 9000 mpirun -np 64 projwfc.x -in proj_P2.in > proj_P2.out 2>&1
  echo "=== P2 projwfc exit=$? done=$(grep -c 'JOB DONE' proj_P2.out 2>/dev/null || echo 0) ==="
fi
rm -rf out_P2
echo "########## COMPLETE $(date +%H:%M:%S) ##########"
exit 0
